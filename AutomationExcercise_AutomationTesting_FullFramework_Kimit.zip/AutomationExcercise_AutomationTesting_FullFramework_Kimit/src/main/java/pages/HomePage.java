package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends PageBase {
	
	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(linkText = "Signup / Login")
	 WebElement loginOrRegisterBtn;
	
	@FindBy(linkText = "Home")
	public WebElement homeBtn;
	
	@FindBy(linkText = "Contact us")
	WebElement contactUsBtn;
	
	@FindBy(linkText = "Test Cases")
	WebElement TestCasesBtn;
	
	@FindBy(xpath = "//a[contains(@href,'/products')]")
	WebElement ProductsBtn;
	
	@FindBy(xpath = "//h2[contains(text(),'All Products')]")
	public WebElement AllProducts;
	
	@FindBy(className = "features_items")
	public WebElement featuredItemsSection;
	
	@FindBy (xpath= "//*[@id=\"footer\"]/div[1]/div/div/div[2]/div/h2")
	public WebElement Subscription;
	
	@FindBy (id= "susbscribe_email")
	public WebElement emailInput;
	
	@FindBy (xpath= "//*[@id=\"subscribe\"]/i")
	public WebElement ArrowBtn;
	
	@FindBy (xpath="//*[@id=\"success-subscribe\"]/div")
	public WebElement successMessage;
	
	@FindBy (xpath= "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")
	public WebElement cartBtn;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[2]/div[1]/div[2]/div/div[2]/ul/li/a")
	public WebElement viewProduct1;
	
	@FindBy (xpath= "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")
	public WebElement DeleteAccBtn;
	
	@FindBy (xpath="//*[@id=\"form\"]/div/div/div/h2/b")
	public WebElement accountDeleted;
	
	@FindBy (xpath="//*[@id=\"form\"]/div/div/div/div/a")
	public WebElement continueBtn;
	
	@FindBy(xpath="//a[contains(.,'Logged in as')]/b")
	public WebElement loggedInAs;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[1]/div/div[3]/h2")
	public WebElement brands;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[1]/div/div[3]")
	public WebElement brandsProducts;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[1]/div/div[3]/div/ul/li[1]/a")
	public WebElement poloBtn;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/h2")
	public WebElement poloRedirection;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/div[2]/div")
	public List<WebElement> poloproductsList;
	
	@FindBy (xpath= "/html/body/section/div/div[2]/div[1]/div[1]/div[2]/div/ul/li[2]/a")
	public WebElement hmBtn;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/h2")
	public WebElement hmRedirection;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/div[2]/div")
	public List<WebElement> hmproductsList;
	
	@FindBy(xpath = "//div[contains(@class,'brands_products')]//a[contains(.,'Polo')]")
	public WebElement poloLink;

	@FindBy(xpath = "//div[contains(@class,'brands_products')]//a[contains(.,'H&M')]")
	public WebElement hmLink;
	
	@FindBy (xpath= "/html/body/section[2]/div/div/div[1]/div/h2")
	public WebElement homeCategory;
	
	@FindBy (xpath= "//*[@id=\"accordian\"]/div[1]/div[1]/h4/a")
	public WebElement women;
	
	@FindBy (xpath= "//*[@id=\"Women\"]/div/ul/li[1]/a")
	public WebElement dress;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/h2")
	public WebElement redirectionConfirmWomen;
	
	@FindBy (xpath="//*[@id=\"accordian\"]/div[2]/div[1]/h4/a")
	public WebElement men;
	
	@FindBy (xpath="//*[@id=\"Men\"]/div/ul/li[1]/a")
	public WebElement tshirts;
	
	@FindBy (xpath="/html/body/section/div/div[2]/div[2]/div/h2")
	public WebElement redirectionConfirmMen;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[2]/div[2]/h2")
	public WebElement recommendedItems;
	
	@FindBy (xpath="//*[@id=\"recommended-item-carousel\"]/div/div[2]/div[1]/div/div/div/a")
	public WebElement addtocartRecommendedBtn;
	
	@FindBy (xpath="//*[@id=\"scrollUp\"]/i")
	public WebElement arrowUp;
	
	@FindBy (xpath="//*[@id=\"header\"]/div/div/div/div[1]/div/a/img")
	public WebElement logo;
	
	
	
	public void openLoginPage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.elementToBeClickable(loginOrRegisterBtn));
		
		loginOrRegisterBtn.click();
	}
	
	public void openRegisterPage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.elementToBeClickable(loginOrRegisterBtn));
		
		loginOrRegisterBtn.click();
	}
	
	public void openHomePage() {
		homeBtn.click();
	}
	
	public void openContactUsPage() {
		contactUsBtn.click();
	}
	
	public void openTestCasesPage() {
		TestCasesBtn.click();
	}
	public void openProductsPage() {

		    ProductsBtn.click();
		
	}
	public void openCartPage() {

	    cartBtn.click();
	
}
	
	
}
