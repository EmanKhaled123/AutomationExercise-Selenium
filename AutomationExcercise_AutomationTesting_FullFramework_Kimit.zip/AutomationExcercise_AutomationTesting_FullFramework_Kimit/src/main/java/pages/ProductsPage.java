package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductsPage extends PageBase{
	public ProductsPage(WebDriver driver) {
		super(driver);
	}
	@FindBy(css = "h2.title.text-center")
	public WebElement AllProducts;
	
	@FindBy(className = "features_items")
	public WebElement featuredItemsSection;
	
	@FindBy(xpath = "//a[contains(text(),'View Product')]")
	public WebElement firstProductDetailsBtn;
	 
	
	@FindBy(xpath = "//div[@class='product-information']/h2")
	public WebElement productName;
	
	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[1]")
	public WebElement CategoryElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/span")
	public WebElement PriceElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]/b")
	public WebElement ConditionElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]/b")
	public WebElement BrandElement;

	@FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]/b")
	public WebElement AvailabilityElement;
	
	@FindBy(id="search_product")
	public WebElement SearchBox;
	
	@FindBy(id="submit_search")
	public WebElement SearchBtn;
	
	@FindBy(xpath = "//h2[contains(text(),'Searched Products')]")
	public WebElement searchedProductsHeader;
	
	@FindBy(className = "product-image-wrapper")
	public  List <WebElement> searchedProductsList;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/a")
		public WebElement AddToCartBtn1;
	@FindBy (xpath= "//*[@id=\"cartModal\"]/div/div/div[3]/button")
		public WebElement ContShopBtn;
	@FindBy(xpath = "//a[@href='/product_details/2']")
	public WebElement secondProductDetailsBtn;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[2]/div/div[3]/div/div[1]/div[2]/div/a")
	public WebElement AddToCartBtn2;
	
	@FindBy (xpath="//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	public WebElement viewCartBtn;
	
	@FindBy(xpath = "//tbody/tr")
	public List<WebElement> productsInCart;
	
	@FindBy (xpath="//*[@id=\"product-1\"]/td[3]")
	public WebElement price1;
	
	@FindBy (xpath= "//*[@id=\"product-1\"]/td[4]")
	public WebElement quantity1;
	
	@FindBy (xpath="//*[@id=\"product-1\"]/td[5]")
	public WebElement total1;
	
	@FindBy (xpath="//*[@id=\"product-2\"]/td[3]")
	public WebElement price2;
	
	@FindBy (xpath= "//*[@id=\"product-2\"]/td[4]")
	public WebElement quantity2;
	
	@FindBy (xpath="//*[@id=\"product-2\"]/td[5]")
	public WebElement total2;
	
	@FindBy(xpath = "(//div[@class='product-image-wrapper'])[1]")
	public WebElement firstProduct;

	@FindBy(xpath = "(//div[@class='product-image-wrapper'])[2]")
	public WebElement secondProduct;
	
	@FindBy (id="quantity")
	public WebElement quantityClicker;
	
	@FindBy (xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")
	public WebElement addToCartBtnQtyChecker;
	
	@FindBy (xpath="//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
	public WebElement viewCartQty;
	
	@FindBy(xpath="//*[@id=\"product-1\"]/td[4]/button")
	public WebElement cartQuantityBtn;
	
	@FindBy (id= "search_product")
	public WebElement search;
	
	@FindBy (xpath="//*[@id=\"submit_search\"]")
	public WebElement searchBtn;
	
	@FindBy (xpath="/html/body/section[2]/div/div/div[2]/div/h2")
	public WebElement searchedProducts;
	
	@FindBy(xpath = "//div[contains(@class,'features_items')]//div[contains(@class,'productinfo')]//p")
	public List<WebElement> searchedProductNames;
	
	@FindBy (xpath="/html/body/section/div/div/div[2]/div[3]/div[1]/ul/li/a")
	public WebElement writeReview;
	
	@FindBy (xpath="//*[@id=\"name\"]")
	public WebElement nameTxtBox;
	
	@FindBy (xpath="//*[@id=\"email\"]")
	public WebElement emailTxtBox;
	
	@FindBy (xpath="//*[@id=\"review\"]")
	public WebElement reviewTxtBox;
	
	@FindBy (xpath="//*[@id=\"button-review\"]")
	public WebElement submitReviewBtn;
	
	@FindBy (xpath="//*[@id=\"review-section\"]/div/div/span")
	public WebElement reviewSuccess;
	
}

