package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartPage extends PageBase{

	public CartPage(WebDriver driver) {
		super(driver);
	}
	@FindBy (xpath ="//*[@id=\"footer\"]/div[1]/div/div/div[2]/div/h2")
	public WebElement subscriptionCart;
	
	@FindBy (xpath= "//*[@id=\"susbscribe_email\"]")
	public WebElement emailSub;
	
	@FindBy (xpath= "//*[@id=\"subscribe\"]")
	public WebElement subArrow;
	
	@FindBy (xpath="//*[@id=\"success-subscribe\"]/div")
	public WebElement successMessage;
	
	@FindBy (xpath="//*[@id=\"do_action\"]/div[1]/div/div/a")
	public WebElement proceedToCheckoutBtn;
	
	@FindBy (xpath="//*[@id=\"checkoutModal\"]/div/div/div[2]/p[2]/a/u") 
	public WebElement RegisterLoginBtn;
	
	@FindBy(xpath = "//*[@id=\"address_delivery\"]/li[2]")
	public WebElement deliveryName;

	@FindBy(xpath = "//*[@id=\"address_delivery\"]/li[4]")
	public WebElement deliveryAddress1;

	@FindBy(xpath = "//*[@id=\"address_delivery\"]/li[6]")
	public WebElement deliveryAddress2;
	
	@FindBy (xpath= "//*[@id=\"address_delivery\"]/li[7]")
	public WebElement deliveryCountry;
	
	@FindBy (xpath="//*[@id=\"address_delivery\"]/li[8]")
	public WebElement mobile;
	
	@FindBy (xpath="//*[@id=\"cart_items\"]/div/div[4]/h2")
	public WebElement reviewOrder;
	
	@FindBy (xpath="//*[@id=\"ordermsg\"]/textarea")
	public WebElement commentArea;
	
	@FindBy(xpath = "//a[contains(text(),'Place Order')]")
	public WebElement placeOrderBtn;
	
	@FindBy (xpath="//*[@id=\"payment-form\"]/div[1]/div/input")
	public WebElement NameTxtBox;
	
	@FindBy (xpath="//*[@id=\"payment-form\"]/div[2]/div/input")
	public WebElement CardNoTxtBox;
	
	@FindBy (xpath="//*[@id=\"payment-form\"]/div[3]/div[1]/input")
	public WebElement CVCtxtbox;
	
	@FindBy (xpath="//*[@id=\"payment-form\"]/div[3]/div[2]/input")
	public WebElement ExpirationTxtBoxMonth;
	
	@FindBy (xpath="//*[@id=\"payment-form\"]/div[3]/div[3]/input")
	public WebElement ExpirationTxtBoxYear;
	
	@FindBy (xpath="//*[@id=\"submit\"]")
	public WebElement payConfirmBtn;
	@FindBy(xpath = "//b[contains(text(),'Order Placed')]")
	public WebElement successMessageConfirm;
	@FindBy (xpath= "//*[@id=\"product-1\"]/td[6]/a/i")
	public WebElement removeBtn1;
	
	@FindBy (xpath="//*[@id=\"product-4\"]/td[2]/h4/a")
	public WebElement recommendedInCart;
	
	@FindBy (xpath="//a[contains(text(),'Download Invoice')]")
	public WebElement downloadInvoiceBtn;
	
	@FindBy(xpath = "//*[@id='form']/div/div[1]/div/div/a")
	public WebElement continueBtn;
}
