package tests;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;

public class VerifyProductQty extends TestBase {
	HomePage homeObject;
	ProductsPage productObject;
	CartPage cartObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
		cartObject= new CartPage(driver);
	}
	
	@Test 
	public void VerifyQty() {
		    Assert.assertTrue(homeObject.featuredItemsSection.isDisplayed());
		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		    js.executeScript("arguments[0].click();", homeObject.viewProduct1);
		     wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		    wait.until(ExpectedConditions.urlContains("product_details"));
		    productObject.quantityClicker.click();
		    productObject.quantityClicker.sendKeys(Keys.ARROW_UP);  
		    productObject.quantityClicker.sendKeys(Keys.ARROW_UP);  
		    productObject.quantityClicker.sendKeys(Keys.ARROW_UP);  
		    productObject.addToCartBtnQtyChecker.click();
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		    js.executeScript("arguments[0].click();", productObject.viewCartQty);
		    Assert.assertEquals(productObject.productsInCart.size(), 1);
		    Assert.assertEquals(productObject.cartQuantityBtn.getText(), "4");
		    
	}


}
