package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.ProductsPage;

public class AddToCart extends TestBase {
	HomePage homeObject;
	ProductsPage productObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
	}

		@Test
		public void addToCart() {
		    homeObject.openProductsPage();
		    Assert.assertTrue(productObject.AllProducts.isDisplayed());
		    Assert.assertTrue(productObject.featuredItemsSection.isDisplayed());

		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		    js.executeScript("arguments[0].click();", productObject.AddToCartBtn1);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		    js.executeScript("arguments[0].click();", productObject.ContShopBtn);

		    js.executeScript("arguments[0].click();", productObject.AddToCartBtn2);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		    js.executeScript("arguments[0].click();", productObject.viewCartBtn);

		    Assert.assertEquals(productObject.productsInCart.size(), 2);
		    Assert.assertTrue(productObject.price1.isDisplayed());
		    Assert.assertTrue(productObject.quantity1.isDisplayed());
		    Assert.assertTrue(productObject.total1.isDisplayed());
		    Assert.assertTrue(productObject.price2.isDisplayed());
		    Assert.assertTrue(productObject.quantity2.isDisplayed());
		    Assert.assertTrue(productObject.total2.isDisplayed());
		
	}
	
	  
}
