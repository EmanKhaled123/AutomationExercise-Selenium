package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;
import pages.RegisterPage;

public class VerifyAddressCheckout extends TestBase {
	HomePage homeObject;
	RegisterPage registerObject;
	ProductsPage productObject;
	CartPage cartObject;
		@BeforeMethod
		public void initializeObjects() {
			homeObject = new HomePage(driver);
			registerObject= new RegisterPage(driver);
			productObject= new ProductsPage (driver);
			cartObject= new CartPage (driver);
		}
		@Test
		public void VerifyCartSub() {
			JavascriptExecutor js = (JavascriptExecutor) driver;
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		    Assert.assertTrue(homeObject.homeBtn.isDisplayed());
		    homeObject.openRegisterPage();
		    registerObject.userCanRegister("Eman Selim", "ek921283@gmail.com");
		    wait.until(ExpectedConditions.urlContains("signup"));
			 registerObject.userCanEnterAccountInformation("eman123456789", 15, "4", "2003", "Eman", "Selim", "DEW", "Maadi", 
					 "Maadi", "India", ".", "Cairo", "1234", "01152555892");
			 Assert.assertTrue(registerObject.successMessage.getText().equalsIgnoreCase("Account Created!"));
			 registerObject.userCanContinue();
			 Assert.assertEquals(registerObject.loggedInAs.getText(), "Eman Selim");
			 js.executeScript("arguments[0].click();", productObject.AddToCartBtn1);
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
			 js.executeScript("arguments[0].click();", productObject.ContShopBtn);
			 js.executeScript("arguments[0].click();", productObject.AddToCartBtn2);
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
			 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
			 js.executeScript("arguments[0].click();", productObject.ContShopBtn);
			 js.executeScript("arguments[0].click();", homeObject.cartBtn);
			 wait.until(ExpectedConditions.urlContains("view_cart"));
			 js.executeScript("arguments[0].click();", cartObject.proceedToCheckoutBtn);
			 wait.until(ExpectedConditions.urlContains("checkout"));
			 Assert.assertEquals(cartObject.deliveryName.getText(), "Mrs. Eman Selim");
			 Assert.assertEquals(cartObject.deliveryAddress1.getText(), "Maadi");
			 Assert.assertEquals(cartObject.deliveryAddress2.getText(), "Cairo . 1234");
			 Assert.assertEquals(cartObject.deliveryCountry.getText(), "India");
			 js.executeScript("arguments[0].click()", homeObject.DeleteAccBtn);
			 Assert.assertTrue(homeObject.accountDeleted.isDisplayed());
			 js.executeScript("arguments[0].click()", homeObject.continueBtn);
			 
		}
		}