package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadLoginNegativeDataProperties;
import pages.HomePage;
import pages.LoginPage;

public class Login_negativeScenarioWittDDTAndJavaPropertiesFile extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	String email1 = LoadLoginNegativeDataProperties.loginNegativeData.getProperty("email1");
	String password1 = LoadLoginNegativeDataProperties.loginNegativeData.getProperty("password1");
	
	String email2 = LoadLoginNegativeDataProperties.loginNegativeData.getProperty("email2");
	String password2 = LoadLoginNegativeDataProperties.loginNegativeData.getProperty("password2");
	
	@DataProvider(name="getNegativeData")
	public Object[][] getLoginNegativeData(){
		Object[][] loginNegativeData = {
				{email1,password1},
				{email2,password2}
		};
		return loginNegativeData;
	}
	
	@Test (priority = 1,dataProvider = "getNegativeData")
	public void testLogin_IncorrectEmailOrIncorrectPassword(String email,String password) throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin(email,password);
		Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
		Thread.sleep(2000);
	}
	
}
