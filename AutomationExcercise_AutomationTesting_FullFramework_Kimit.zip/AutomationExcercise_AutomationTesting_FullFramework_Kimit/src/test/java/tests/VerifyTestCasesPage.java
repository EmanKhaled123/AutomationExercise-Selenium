package tests;

import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.ContactUsPage;
import pages.HomePage;

public class VerifyTestCasesPage extends TestBase{
	HomePage homeObject;
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		
	}
	@Test
	public void VerifyTestCasesPage() {
		Assert.assertTrue(homeObject.homeBtn.isDisplayed());
		homeObject.openTestCasesPage();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	    wait.until(ExpectedConditions.urlContains("test_cases"));

	    Assert.assertTrue(driver.getCurrentUrl().contains("test_cases"));
	}
}
