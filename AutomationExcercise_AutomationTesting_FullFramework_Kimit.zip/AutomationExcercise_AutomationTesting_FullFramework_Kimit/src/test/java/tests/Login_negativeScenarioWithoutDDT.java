package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_negativeScenarioWithoutDDT extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}

	@Test (priority = 1)
	public void testLogin_CorrectUsernameAndNotMatchingPassword() throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin("abdelrahmanosama769@gmail.com","a1234567");
		Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
		Thread.sleep(2000);
	}
	
	@Test (priority = 2,dependsOnMethods = {"testLogin_CorrectUsernameAndNotMatchingPassword"})
	public void testLogin_InCorrectUsername() throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin("abdelrahmanosama7@gmail.com","a123456789");
		Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
		Thread.sleep(2000);
	}
}
