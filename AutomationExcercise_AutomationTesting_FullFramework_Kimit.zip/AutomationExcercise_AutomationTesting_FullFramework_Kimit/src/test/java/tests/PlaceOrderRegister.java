package tests;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;
public class PlaceOrderRegister extends TestBase {
	HomePage homeObject;
	ProductsPage productObject;
	CartPage cartObject;
	LoginPage loginObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
		cartObject= new CartPage(driver);
		loginObject= new LoginPage(driver);
	}
	@Test
	public void PlaceOrder() throws InterruptedException {
	    Assert.assertTrue(homeObject.homeBtn.isDisplayed());
	    Assert.assertTrue(homeObject.featuredItemsSection.isDisplayed());
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    js.executeScript("arguments[0].click();", productObject.AddToCartBtn1);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
	    js.executeScript("arguments[0].click();", productObject.ContShopBtn);
	    js.executeScript("arguments[0].click();", productObject.AddToCartBtn2);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
	    js.executeScript("arguments[0].click();", productObject.viewCartBtn);
	    wait.until(ExpectedConditions.urlContains("view_cart"));
	    js.executeScript("arguments[0].click();", cartObject.proceedToCheckoutBtn);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".modal-content")));
	    js.executeScript("arguments[0].click();", cartObject.RegisterLoginBtn);
	    wait.until(ExpectedConditions.urlContains("login"));
	    loginObject.userCanLogin("abdelrahmanosama767@gmail.com", "a123456789");
	    wait.until(ExpectedConditions.urlContains("automationexercise.com"));
	    js.executeScript("arguments[0].click();", homeObject.cartBtn);
	    wait.until(ExpectedConditions.urlContains("view_cart"));
	    js.executeScript("arguments[0].click();", cartObject.proceedToCheckoutBtn);
	    wait.until(ExpectedConditions.urlContains("checkout"));
	    Assert.assertEquals(cartObject.deliveryName.getText(), "Mr. Abdelrahman Osama");
	    Assert.assertEquals(cartObject.deliveryAddress1.getText(), "Fostat");
	    Assert.assertEquals(cartObject.deliveryAddress2.getText(), "Cairo Egypt 123456");
	    Assert.assertEquals(cartObject.deliveryCountry.getText(), "India");
	    Assert.assertEquals(cartObject.mobile.getText(), "01013440554");
	    Assert.assertTrue(cartObject.reviewOrder.isDisplayed());
	    cartObject.commentArea.sendKeys("here");
	    js.executeScript("arguments[0].click();", cartObject.placeOrderBtn);
	    wait.until(ExpectedConditions.visibilityOf(cartObject.NameTxtBox));
	    cartObject.NameTxtBox.sendKeys("EMAN KHALED");
	    cartObject.CardNoTxtBox.sendKeys("5178790080369219");
	    cartObject.CVCtxtbox.sendKeys("119");
	    cartObject.ExpirationTxtBoxMonth.sendKeys("07");
	    cartObject.ExpirationTxtBoxYear.sendKeys("2029");
	    js.executeScript("arguments[0].click();", cartObject.payConfirmBtn);
	    	wait.until(ExpectedConditions.visibilityOf(cartObject.successMessageConfirm));
	    Assert.assertTrue(cartObject.successMessageConfirm.isDisplayed());
	    wait.until(ExpectedConditions.urlContains("payment_done"));
	    js.executeScript("arguments[0].click();", homeObject.DeleteAccBtn);
	    wait.until(ExpectedConditions.visibilityOf(homeObject.accountDeleted));
	    Assert.assertTrue(homeObject.accountDeleted.isDisplayed());
	    js.executeScript("arguments[0].click();", homeObject.continueBtn);
	}
}
