package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;

public class RemoveFromCart extends TestBase {
	HomePage homeObject;
	CartPage cartObject;
	ProductsPage productObject;
	
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);	
		cartObject= new CartPage(driver);
		productObject= new ProductsPage (driver);
	}
	@Test
	public void removeFromCart() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Assert.assertTrue(homeObject.homeBtn.isDisplayed());
		homeObject.openProductsPage();
	    Assert.assertTrue(productObject.AllProducts.isDisplayed());
	    js.executeScript("arguments[0].click();", productObject.AddToCartBtn1);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		js.executeScript("arguments[0].click();", productObject.ContShopBtn);
		js.executeScript("arguments[0].click();", productObject.AddToCartBtn2);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		js.executeScript("arguments[0].click();", productObject.ContShopBtn);
		js.executeScript("arguments[0].click();", homeObject.cartBtn);
	    wait.until(ExpectedConditions.urlContains("view_cart"));
	    js.executeScript("arguments[0].click();", cartObject.removeBtn1);
	    wait.until(ExpectedConditions.numberOfElementsToBe(
	        By.cssSelector("#cart_info_table tbody tr"), 1));
	    Assert.assertEquals(
	    	    driver.findElements(By.cssSelector("#cart_info_table tbody tr")).size(), 1
	    	);
	}
	
}
