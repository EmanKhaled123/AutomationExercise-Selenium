package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;

public class SearchProductsVerifyCartLogin extends TestBase {
	HomePage homeObject;
	CartPage cartObject;
	ProductsPage productObject;
	LoginPage loginObject;
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);	
		cartObject= new CartPage(driver);
		productObject= new ProductsPage (driver);
		loginObject= new LoginPage(driver);
		
	}
	@Test
	public void SearchVerifyAfterLogin() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		homeObject.openProductsPage();
		Assert.assertTrue(productObject.AllProducts.isDisplayed());
	    productObject.search.sendKeys("polo");
	    js.executeScript("arguments[0].click();", productObject.searchBtn);
	    Assert.assertTrue(productObject.searchedProducts.isDisplayed());
	    int searchResultCount = productObject.searchedProductNames.size(); 
	    for (WebElement product : productObject.searchedProductNames) {
	        Assert.assertTrue(product.getText().toLowerCase().contains("polo"));
	    WebElement addToCartBtn = product.findElement(
	            By.xpath("following-sibling::a[contains(@class,'add-to-cart')]"));
	        js.executeScript("arguments[0].click();", addToCartBtn);
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
	        js.executeScript("arguments[0].click();", productObject.ContShopBtn);
	    }
	    homeObject.openCartPage();
	    wait.until(ExpectedConditions.urlContains("view_cart"));
	    Assert.assertEquals(
	        driver.findElements(By.cssSelector("#cart_info_table tbody tr")).size(),searchResultCount); 
	    homeObject.openLoginPage();
	    wait.until(ExpectedConditions.urlContains("login"));
	    loginObject.userCanLogin("emankhaled4776@gmail.com", "eman123456789");
	    wait.until(ExpectedConditions.urlContains("automationexercise.com"));
	    Assert.assertEquals(homeObject.loggedInAs.getText(), "Eman Khaled");
	    homeObject.openCartPage();
	    wait.until(ExpectedConditions.urlContains("view_cart"));
	    Assert.assertEquals(
	     driver.findElements(By.cssSelector("#cart_info_table tbody tr")).size(),
	     searchResultCount
	 );
    
	}
	}