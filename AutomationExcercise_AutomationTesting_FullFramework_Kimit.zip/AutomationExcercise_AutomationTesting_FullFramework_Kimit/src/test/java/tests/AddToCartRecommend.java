package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;

public class AddToCartRecommend   extends TestBase{
	HomePage homeObject;
	ProductsPage productObject;
	CartPage cartObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
		cartObject= new CartPage(driver);	
	}
	@Test
	public void addToCartRecommend() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	    Assert.assertTrue(homeObject.recommendedItems.isDisplayed());
	    js.executeScript("arguments[0].click()", homeObject.addtocartRecommendedBtn);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
	    js.executeScript("arguments[0].click();", productObject.viewCartBtn);
	    Assert.assertTrue(cartObject.recommendedInCart.isDisplayed());
	}
}
