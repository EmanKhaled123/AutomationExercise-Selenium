package tests;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;

public class VerifyCart extends TestBase {
HomePage homeObject;
CartPage cartObject;
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		cartObject= new CartPage(driver);
	}
	@Test
	public void VerifyCartSub() {
		homeObject.cartBtn.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Assert.assertTrue(cartObject.subscriptionCart.isDisplayed());
		cartObject.emailSub.sendKeys("emankhaled4776@gmail.com");
		cartObject.subArrow.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	    wait.until(ExpectedConditions.visibilityOf(cartObject.successMessage));
		Assert.assertTrue(cartObject.successMessage.isDisplayed());
	}

}
