package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenarioWithoutDDT extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	@Test
	public void testLogin_CorrectUsernameAndMatchingPassword() throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin("abdelrahmanosama769@gmail.com","a123456789");
		Assert.assertTrue(loginObject.logoutBtn.isEnabled());
		Thread.sleep(2000);
		
		loginObject.userCanLogout();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
	}
}
