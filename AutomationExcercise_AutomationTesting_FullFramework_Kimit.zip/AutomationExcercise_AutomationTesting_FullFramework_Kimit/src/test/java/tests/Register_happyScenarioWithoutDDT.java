package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class Register_happyScenarioWithoutDDT extends TestBase{
	HomePage homeObject;
	RegisterPage registerObject;
	
	public void intializeObjects() {
		homeObject = new HomePage(driver);
		registerObject = new RegisterPage(driver);
	}

	@Test(priority = 1)
	public void testRegister_ValidMandatoryAndOptionalFieldsWithNewEmail() throws InterruptedException {
		
		intializeObjects();
		
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");
		
		homeObject.openRegisterPage();
		Assert.assertEquals(registerObject.registerMessage.getText(), "New User Signup!");
		
		registerObject.userCanRegister("Abdelrahman Osama", "abdelrahmanosama7611@gmail.com");
		Assert.assertEquals(registerObject.enterAccountMessage.getText(), "ENTER ACCOUNT INFORMATION");

		registerObject.userCanEnterAccountInformation("a123456789", 20, "5", 
				"2003", "Abdelrahman","Osama", "Itworx"
				,"Fostat", "Nasr City", "India", "Cairo", 
				"Cairo", "13498", "01013440554");
		
		Assert.assertTrue(registerObject.successMessage.getText().equalsIgnoreCase("Account Created!"));

		registerObject.userCanContinue();
		Assert.assertTrue(registerObject.deleteAccountBtn.isEnabled());

		registerObject.userCanDeleteAccount();
		Assert.assertEquals(registerObject.deleteSuccessMessage.getText(), "ACCOUNT DELETED!");

		registerObject.userCanContinue();
		
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");
	}
	
	@Test(priority = 2,dependsOnMethods = {"testRegister_ValidMandatoryAndOptionalFieldsWithNewEmail"})
	public void testRegister_ValidMandatoryFieldsWithNewEmail() throws InterruptedException {
		intializeObjects();
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");

		homeObject.openRegisterPage();
		Assert.assertEquals(registerObject.registerMessage.getText(), "New User Signup!");
		
		registerObject.userCanRegister("Abdelrahman Osama", "abdelrahmanosama7611@gmail.com");
		Assert.assertEquals(registerObject.enterAccountMessage.getText(), "ENTER ACCOUNT INFORMATION");

		registerObject.userCanEnterAccountInformation("a123456789", "Abdelrahman","Osama"
														,"Fostat", "India", "Cairo", 
														"Cairo", "13498", "01013440554");
		
		Assert.assertTrue(registerObject.successMessage.getText().equalsIgnoreCase("Account Created!"));

		registerObject.userCanContinue();
		Assert.assertTrue(registerObject.deleteAccountBtn.isEnabled());

		registerObject.userCanDeleteAccount();
		Assert.assertEquals(registerObject.deleteSuccessMessage.getText(), "ACCOUNT DELETED!");

		registerObject.userCanContinue();
		
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");
	}
}
