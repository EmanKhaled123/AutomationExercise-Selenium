package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.ProductsPage;


public class VerifyProductsSearch extends TestBase{
	HomePage homeObject;
	ProductsPage productObject;
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);
		
	}
	@Test
	public void VerifyProductSearch() {
		Assert.assertTrue(homeObject.homeBtn.isDisplayed());
		homeObject.openProductsPage();
		Assert.assertTrue(productObject.AllProducts.isDisplayed());
		productObject.SearchBox.sendKeys("polo");
		productObject.SearchBtn.click();
		Assert.assertTrue(productObject.searchedProductsHeader.isDisplayed());
		Assert.assertTrue(productObject.searchedProductsList.size()>=1);
	}
	

}
