package tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadLoginNegativeDataExcel;
import pages.HomePage;
import pages.LoginPage;

public class Login_negativeScenarioWithDDTAndExcelSheet extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	@DataProvider(name="loginNegativeDataExcel")
	public Object[][] getLoginNegativeData() throws IOException{
		LoadLoginNegativeDataExcel loginNegativeData = new LoadLoginNegativeDataExcel();
		return loginNegativeData.getExcelFileData();
	}; 
	
	@Test (priority = 1,dataProvider = "loginNegativeDataExcel")
	public void testLogin_IncorrectUsernameOrPassword(String email,String password) throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin(email,password);
		Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
		Thread.sleep(2000);
	}
	
}
