package tests;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.HomePage;



public class VerifyScrollUp extends TestBase{
	HomePage homeObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);	
	}
	
	@Test
	public void VerifyScrollup() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	    Assert.assertTrue(homeObject.homeBtn.isDisplayed());
	    js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	    Assert.assertTrue(homeObject.Subscription.isDisplayed());
	    js.executeScript("arguments[0].click()", homeObject.arrowUp);
	    js.executeScript("window.scrollTo(0, 0);");
	    wait.until(ExpectedConditions.visibilityOf(homeObject.logo));
	    Assert.assertTrue(homeObject.logo.isDisplayed());
	    
		
	}
	

}
