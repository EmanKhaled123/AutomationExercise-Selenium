package tests;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;

public class VerifySubscription extends TestBase {
	HomePage homeObject;
	
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
	}
	@Test
	public void verifySub() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Assert.assertTrue(homeObject.Subscription.isDisplayed());
		homeObject.emailInput.sendKeys("emankhaled4776@gmail.com");
		homeObject.ArrowBtn.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	    wait.until(ExpectedConditions.visibilityOf(homeObject.successMessage));
		Assert.assertTrue(homeObject.successMessage.isDisplayed());
	}
}
