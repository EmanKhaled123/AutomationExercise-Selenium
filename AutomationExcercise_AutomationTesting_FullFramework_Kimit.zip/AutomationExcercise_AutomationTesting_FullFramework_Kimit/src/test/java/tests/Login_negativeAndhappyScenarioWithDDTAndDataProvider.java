package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_negativeAndhappyScenarioWithDDTAndDataProvider extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	@DataProvider(name = "Login_negativeAndhappyData")
	public Object [][] getLoginNegativeData() {
		Object loginNegativeAndhappyData [][] = {
				{"abdelrahmanosama769@gmail.com","a123456789",true}, // positive
				{"abdelrahmanosama7@gmail.com","a123456789",false}, // negative
				{"ibrahimfago@gmail.com","a123456789",false} // negative
		};
		
		return loginNegativeAndhappyData;
	}
	
	@Test (priority = 1,dataProvider = "Login_negativeAndhappyData")
	public void testLogin_LoginAllTests_happyAndNegative(String email,String password,boolean isLoginSuccessfull) throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin(email,password);
		
		if(isLoginSuccessfull) {
			Assert.assertTrue(loginObject.logoutBtn.isEnabled());
			Thread.sleep(2000);
			
			loginObject.userCanLogout();
			Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		}
		else {
			Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
			Thread.sleep(2000);
		}
	}
	

//	@Test (priority = 1,dataProvider = "Login_negativeData")
//	public void testLogin_IncorrectUsernameORIncorrectPassword(String email,String password) throws InterruptedException {
//		initializeObject();
//		
//		homeObject.openLoginPage();
//		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
//		Thread.sleep(2000);
//		
//		loginObject.userCanLogin(email,password);
//		 
//		/// Negative 
////		Assert.assertEquals(loginObject.errorMessage.getText(), "Your email or password is incorrect!");
////		Thread.sleep(2000);

//	}
	
	
}
