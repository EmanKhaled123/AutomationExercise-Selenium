package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoadRegisterHappyDataExcel {
	FileInputStream stream= null;
	
	public FileInputStream getExcelFile() throws FileNotFoundException {
		String filePath= System.getProperty("user.dir") + "\\src\\test\\java\\Excel\\Register_happyData.xlsx";
		File file= new File (filePath);
		if (file.exists()) {
			stream = new FileInputStream(file);
		}
		else {
			System.out.println("FNF!");
		}
		return stream;
		
	}
	public Object [][] getExcelFileHappyData() throws IOException{
		stream= getExcelFile();
		XSSFWorkbook workbook= new XSSFWorkbook (stream);
		XSSFSheet registersheet= workbook.getSheet("Register_happyData");
		int nRows= registersheet.getLastRowNum()+1;
		int nCols=17;
		Object [][] ExcelHappyData= new Object [nRows][nCols];
		for (int i=0; i<nRows; i++) {
			XSSFRow row= registersheet.getRow(i);
			for (int j=0 ; j<nCols; j++) {
				ExcelHappyData[i][j]= row.getCell(j).toString();
				
			}
		}
		
		return null;
		
	}

}
