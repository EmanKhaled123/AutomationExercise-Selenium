package tests;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;

public class ProductReview extends TestBase{
	HomePage homeObject;
	ProductsPage productObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
	}
	
	@Test 
	public void AddReview() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		homeObject.openProductsPage();
		Assert.assertTrue(productObject.AllProducts.isDisplayed());
		js.executeScript("arguments[0].click();", productObject.firstProductDetailsBtn);
		Assert.assertTrue(productObject.writeReview.isDisplayed());
		productObject.nameTxtBox.sendKeys("Eman Khaled");
		productObject.emailTxtBox.sendKeys("emankhaled4776@gmail.com");
		productObject.reviewTxtBox.sendKeys("Great Product!");
		js.executeScript("arguments[0].click()", productObject.submitReviewBtn);
		wait.until(ExpectedConditions.visibilityOf(productObject.reviewSuccess));
	    Assert.assertTrue(productObject.reviewSuccess.isDisplayed());	
	}

}
