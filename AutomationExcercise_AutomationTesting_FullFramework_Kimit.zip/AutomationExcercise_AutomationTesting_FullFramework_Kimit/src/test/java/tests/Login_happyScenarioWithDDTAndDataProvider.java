package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenarioWithDDTAndDataProvider extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	@DataProvider(name="LoginHappyData")
	public Object[][] getLoginHappyData(){
		Object[][] loginHappyData = {
				{"abdelrahmanosama769@gmail.com","a123456789"},
		};
		
		return loginHappyData;
	}
	
	@Test(dataProvider = "LoginHappyData")
	public void testLogin_CorrectUsernameAndMatchingPassword(String email,String password) throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin(email,password);
		Assert.assertTrue(loginObject.logoutBtn.isEnabled());
		Thread.sleep(2000);
		
		loginObject.userCanLogout();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
	}
}
