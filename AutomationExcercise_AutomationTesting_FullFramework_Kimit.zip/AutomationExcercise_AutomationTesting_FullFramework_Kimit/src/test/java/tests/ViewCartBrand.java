package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;

public class ViewCartBrand extends TestBase {
	HomePage homeObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);	
	}
	
@Test
	public void viewCartBrand() {
	JavascriptExecutor js = (JavascriptExecutor) driver;
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	homeObject.openProductsPage();
	wait.until(ExpectedConditions.visibilityOf(homeObject.brands));
	Assert.assertTrue(homeObject.brands.isDisplayed());
	 Assert.assertTrue(homeObject.poloLink.isDisplayed());
	Assert.assertTrue(homeObject.hmLink.isDisplayed());
		js.executeScript("arguments[0].click();", homeObject.poloBtn);
	wait.until(ExpectedConditions.visibilityOf(homeObject.poloRedirection));
	Assert.assertTrue(homeObject.poloRedirection.isDisplayed());
	Assert.assertFalse(homeObject.poloproductsList.isEmpty());
	js.executeScript("arguments[0].click();", homeObject.hmBtn);
	wait.until(ExpectedConditions.visibilityOf(homeObject.hmRedirection));
	Assert.assertTrue(homeObject.hmRedirection.isDisplayed());
	Assert.assertFalse(homeObject.hmproductsList.isEmpty());
}
}