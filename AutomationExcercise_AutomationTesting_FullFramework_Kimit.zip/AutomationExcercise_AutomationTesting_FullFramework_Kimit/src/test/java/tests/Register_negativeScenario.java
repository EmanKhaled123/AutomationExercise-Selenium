package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class Register_negativeScenario extends TestBase{
	HomePage homeObject;
	RegisterPage registerObject;
	
	public void intializeObjects() {
		homeObject = new HomePage(driver);
		registerObject = new RegisterPage(driver);
	}
	
	@Test
	public void testRegister_ValidMandatoryAndOptionalWithExistEmail() throws InterruptedException {
		intializeObjects();
		
		homeObject.openRegisterPage();
		Assert.assertEquals(registerObject.registerMessage.getText(), "New User Signup!");
		
		registerObject.userCanRegister("Abdelrahman Osama", "abdelrahmanosama769@gmail.com");
		Assert.assertEquals(registerObject.errorMessage.getText(), "Email Address already exist!");

	}
}
