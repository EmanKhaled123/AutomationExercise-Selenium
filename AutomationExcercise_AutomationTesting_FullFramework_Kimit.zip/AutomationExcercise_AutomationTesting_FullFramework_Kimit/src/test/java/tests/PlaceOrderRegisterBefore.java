package tests;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;
import pages.RegisterPage;

public class PlaceOrderRegisterBefore extends TestBase {
	HomePage homeObject;
	ProductsPage productObject;
	CartPage cartObject;
	RegisterPage registerObject;
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		productObject= new ProductsPage(driver);	
		cartObject= new CartPage(driver);
		registerObject= new RegisterPage (driver);
	}
	
	@Test
	public void RegisterBeforeCheckout() {
		Assert.assertTrue(homeObject.homeBtn.isDisplayed());
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		homeObject.openRegisterPage();
		registerObject.userCanRegister("Eman Khaled", "emankhaled4776@gmail.com");
		 wait.until(ExpectedConditions.urlContains("signup"));
		 registerObject.userCanEnterAccountInformation("eman123456789", 15, "4", "2003", "Eman", "Selim", "DEW", "Maadi", 
				 "Maadi", "India", ".", "Cairo", "1234", "01152555892");
		 Assert.assertTrue(registerObject.successMessage.getText().equalsIgnoreCase("Account Created!"));
		 registerObject.userCanContinue();
		 Assert.assertEquals(registerObject.loggedInAs.getText(), "Eman Khaled");
		 js.executeScript("arguments[0].click();", productObject.AddToCartBtn1);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		 js.executeScript("arguments[0].click();", productObject.ContShopBtn);
		 js.executeScript("arguments[0].click();", productObject.AddToCartBtn2);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cartModal")));
		 js.executeScript("arguments[0].click();", productObject.ContShopBtn);
		 js.executeScript("arguments[0].click();", homeObject.cartBtn);
		 wait.until(ExpectedConditions.urlContains("view_cart"));
		 js.executeScript("arguments[0].click();", cartObject.proceedToCheckoutBtn);
		 wait.until(ExpectedConditions.urlContains("checkout"));
		 Assert.assertEquals(cartObject.deliveryName.getText(), "Mrs. Eman Selim");
		 Assert.assertEquals(cartObject.deliveryAddress1.getText(), "Maadi");
		 Assert.assertEquals(cartObject.deliveryAddress2.getText(), "Cairo . 1234");
		 Assert.assertEquals(cartObject.deliveryCountry.getText(), "India");
		 Assert.assertEquals(cartObject.mobile.getText(), "01152555892");
		 Assert.assertTrue(cartObject.reviewOrder.isDisplayed());
		 cartObject.commentArea.sendKeys("The products are here");
		    js.executeScript("arguments[0].click();", cartObject.placeOrderBtn);
		    wait.until(ExpectedConditions.visibilityOf(cartObject.NameTxtBox));
		    cartObject.NameTxtBox.sendKeys("EMAN KHALED");
		    cartObject.CardNoTxtBox.sendKeys("5178790080369219");
		    cartObject.CVCtxtbox.sendKeys("119");
		    cartObject.ExpirationTxtBoxMonth.sendKeys("07");
		    cartObject.ExpirationTxtBoxYear.sendKeys("2029");
		    js.executeScript("arguments[0].click();", cartObject.payConfirmBtn);
		    	wait.until(ExpectedConditions.visibilityOf(cartObject.successMessageConfirm));
		    Assert.assertTrue(cartObject.successMessageConfirm.isDisplayed());
		    wait.until(ExpectedConditions.urlContains("payment_done"));
		    js.executeScript("arguments[0].click();", homeObject.DeleteAccBtn);
		    wait.until(ExpectedConditions.visibilityOf(homeObject.accountDeleted));
		    Assert.assertTrue(homeObject.accountDeleted.isDisplayed());
		    js.executeScript("arguments[0].click();", homeObject.continueBtn);
		 
	}

}
