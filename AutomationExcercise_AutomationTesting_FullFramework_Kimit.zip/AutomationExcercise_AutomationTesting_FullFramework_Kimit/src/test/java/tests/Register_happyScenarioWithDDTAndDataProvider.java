package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class Register_happyScenarioWithDDTAndDataProvider extends TestBase{
	HomePage homeObject;
	RegisterPage registerObject;
	
	public void intializeObjects() {
		homeObject = new HomePage(driver);
		registerObject = new RegisterPage(driver);
	}
	
	@DataProvider(name="getRegisterHappyData")
	public Object[][] getRegisterHappyData(){
		Object[][] registerHappyData = {
				{"Abdelrahman Osama","abderlahmanosama5666@gmail.com","a123456789",10,"5","2000","Abdelrahman","Osama","Itworx","Cairo","Giza","India","Egypt","Cairo","14756","01013440554",true},
				{"Abdelrahman Osama","abderlahmanosama5666@gmail.com","a123456789",0,null,null,"Abdelrahman","Osama",null,"Cairo",null,"India","Egypt","Cairo","14756","01013440554",false},
				{"Ibrahim fago","ibrahim@gmail.com","a12345678",5,"11","2000","Ibrahim","Fago","Itworx","Cairo","Giza","India","Egypt","Cairo","14756","01013440554",true},
		};
		
		return registerHappyData;
	}
	
	@Test(priority = 1,dataProvider = "getRegisterHappyData")
	public void testRegister_ValidMandatoryAndOptionalFieldsWithNewEmail(String name,String email,String password,int days,
			String month,String year,String firstName,String lastName,
			String company,String address1,String address2,String country,
			String state,String city,String zipCode,String mobileNumber,boolean isMandatoryAndOptional) throws InterruptedException {
		
		intializeObjects();
		
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");
		
		homeObject.openRegisterPage();
		Assert.assertEquals(registerObject.registerMessage.getText(), "New User Signup!");
		
		registerObject.userCanRegister(name, email);
		Assert.assertEquals(registerObject.enterAccountMessage.getText(), "ENTER ACCOUNT INFORMATION");
		
		if(isMandatoryAndOptional) {
			registerObject.userCanEnterAccountInformation(password, days, month, 
					year, firstName,lastName, company
					,address1, address2, country, state, 
					city, zipCode, mobileNumber);
		}
		else {
			registerObject.userCanEnterAccountInformation(password, firstName,lastName
					,address1, country, state, 
					city, zipCode, mobileNumber);
		}
		
		Assert.assertTrue(registerObject.successMessage.getText().equalsIgnoreCase("Account Created!"));

		registerObject.userCanContinue();
		Assert.assertTrue(registerObject.deleteAccountBtn.isEnabled());

		registerObject.userCanDeleteAccount();
		Assert.assertEquals(registerObject.deleteSuccessMessage.getText(), "ACCOUNT DELETED!");

		registerObject.userCanContinue();
		
		Assert.assertEquals(homeObject.homeBtn.getCssValue("color"), "rgba(255, 165, 0, 1)");
	}
	
}
