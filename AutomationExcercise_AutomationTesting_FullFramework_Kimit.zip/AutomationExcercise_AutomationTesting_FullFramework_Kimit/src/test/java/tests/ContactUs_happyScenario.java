package tests;

import java.awt.AWTException;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ContactUsPage;
import pages.HomePage;

public class ContactUs_happyScenario extends TestBase{
	HomePage homeObject;
	ContactUsPage contactUsObject;
	
	public void initializeObjects() {
		homeObject = new HomePage(driver);
		contactUsObject = new ContactUsPage(driver);
	}
	
	@Test
	public void testContactUs_ValidAllFields() throws AWTException, InterruptedException {
		initializeObjects();
		
		homeObject.openContactUsPage();
		
		Assert.assertEquals(contactUsObject.contactUsMessage.getText(), "GET IN TOUCH");
		
		String filePath = System.getProperty("user.dir") + "\\Images\\HarryKane.jpg";
		
//		contactUsObject.userCanContactUs_DirectWay("Abdelrahman Osama", "abdelrahmanosama@gmail.com", "Complain", "My order doesn't deliver yet", filePath);
		contactUsObject.userCanContactUs_RobotWay("Abdelrahman Osama", "abdelrahmanosama@gmail.com", "Complain", "My order doesn't deliver yet", filePath);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.alertIsPresent());
		
		Alert confirmAlert = driver.switchTo().alert();
		Assert.assertEquals(confirmAlert.getText(), "Press OK to proceed!");
		
		confirmAlert.accept();
		
		Assert.assertEquals(contactUsObject.successMessage.getText(), "Success! Your details have been submitted successfully.");
	}
}
