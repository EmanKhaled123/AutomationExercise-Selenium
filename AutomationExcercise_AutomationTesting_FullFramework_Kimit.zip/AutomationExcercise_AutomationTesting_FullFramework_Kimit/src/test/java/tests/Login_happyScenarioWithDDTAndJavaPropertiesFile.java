package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadLoginHappyDataProperties;
import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenarioWithDDTAndJavaPropertiesFile extends TestBase {
	HomePage homeObject;
	LoginPage loginObject;
	
	public void initializeObject() {
		homeObject = new HomePage(driver);
		loginObject = new LoginPage(driver);
	}
	
	String email1 = LoadLoginHappyDataProperties.LoginHappyData.getProperty("email1");
	String password1 = LoadLoginHappyDataProperties.LoginHappyData.getProperty("password1");
		
	String email2 = LoadLoginHappyDataProperties.LoginHappyData.getProperty("email2");
	String password2 = LoadLoginHappyDataProperties.LoginHappyData.getProperty("password2");
		
	@DataProvider(name="getLoginHappyDataProperties")
	Object[][] getLoginHappyData(){
		Object[][] loginHappyData = {
				{email1,password1},
				{email2,password2}
		};
		
		return loginHappyData;
	}
	
	@Test (dataProvider = "getLoginHappyDataProperties")
	public void testLogin_CorrectUsernameAndMatchingPassword(String email,String password) throws InterruptedException {
		initializeObject();
		
		homeObject.openLoginPage();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
		
		loginObject.userCanLogin(email,password);
		Assert.assertTrue(loginObject.logoutBtn.isEnabled());
		Thread.sleep(2000);
		
		loginObject.userCanLogout();
		Assert.assertEquals(loginObject.loginMessage.getText(), "Login to your account");
		Thread.sleep(2000);
	}
}
