package tests;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductsPage;

public class ViewCategory extends TestBase {
	HomePage homeObject;
	CartPage cartObject;
	ProductsPage productObject;
	
	
	@BeforeMethod
	public void initializeObjects() {
		homeObject = new HomePage(driver);	
		cartObject= new CartPage(driver);
		productObject= new ProductsPage (driver);
	}
	@Test
	public void viewCategory() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Assert.assertTrue(homeObject.homeCategory.isDisplayed());
		js.executeScript("arguments[0].click();", homeObject.women);
		js.executeScript("arguments[0].click();", homeObject.dress);
		wait.until(ExpectedConditions.visibilityOf(homeObject.redirectionConfirmWomen));
		Assert.assertTrue(homeObject.redirectionConfirmWomen.isDisplayed());
		js.executeScript("arguments[0].click();", homeObject.men);
		js.executeScript("arguments[0].click();", homeObject.tshirts);
		wait.until(ExpectedConditions.visibilityOf(homeObject.redirectionConfirmMen));
		Assert.assertTrue(homeObject.redirectionConfirmMen.isDisplayed());
	}
}
