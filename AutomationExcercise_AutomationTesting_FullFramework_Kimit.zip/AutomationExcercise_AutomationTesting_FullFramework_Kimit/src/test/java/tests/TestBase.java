package tests;

import org.testng.annotations.BeforeTest;

import data.LoadBrowserCommandsProperties;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
/// int ==> Integer
/// double ==> Double
/// long = Long

public class TestBase {
	static WebDriver driver;
	String baseURL = "https://automationexercise.com/";
	String browserName = LoadBrowserCommandsProperties.browsrCommands.getProperty("browserName");
	String timeout = LoadBrowserCommandsProperties.browsrCommands.getProperty("timeout");
	
	@BeforeTest
	public void openWebsite() {
		if(browserName.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		}
		if(browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		if(browserName.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		
		driver.manage().window().maximize();
		driver.navigate().to(baseURL);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Long.parseLong(timeout)));
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void closeWebsite() {
		driver.quit();
	}
}
