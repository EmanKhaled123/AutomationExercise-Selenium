package tests;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.ContactUsPage;

import pages.ContactUsPage;
import pages.HomePage;
import pages.ProductsPage;
public class VerifyProductsPage extends TestBase {
	
		HomePage homeObject;
		ProductsPage productObject;
		
		@BeforeMethod
		public void initializeObjects() {
			homeObject = new HomePage(driver);
			productObject= new ProductsPage(driver);
			
		}
		@Test
		public void VerifyAllProductsPage() {
			Assert.assertTrue(homeObject.homeBtn.isDisplayed());
			homeObject.openProductsPage();
		    Assert.assertTrue(productObject.AllProducts.isDisplayed());
		    Assert.assertTrue(productObject.featuredItemsSection.isDisplayed());
		    JavascriptExecutor js = (JavascriptExecutor) driver;
		    js.executeScript("arguments[0].click();", productObject.firstProductDetailsBtn);
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		    wait.until(ExpectedConditions.urlContains("product_details"));
		    Assert.assertTrue(driver.getCurrentUrl().contains("product_details"));
		    Assert.assertTrue(productObject.AvailabilityElement.isDisplayed());
		    Assert.assertTrue(productObject.BrandElement.isDisplayed());
		    Assert.assertTrue(productObject.CategoryElement.isDisplayed());
		    Assert.assertTrue(productObject.ConditionElement.isDisplayed());
		    Assert.assertTrue(productObject.PriceElement.isDisplayed());
		    Assert.assertTrue(productObject.productName.isDisplayed());
		}
	}


