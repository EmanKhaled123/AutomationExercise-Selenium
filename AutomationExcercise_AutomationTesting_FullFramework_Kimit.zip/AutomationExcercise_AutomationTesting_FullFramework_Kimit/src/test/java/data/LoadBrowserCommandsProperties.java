package data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoadBrowserCommandsProperties {
	public static Properties browsrCommands = getBrowserCommands(System.getProperty("user.dir") + "\\src\\test\\java\\PropertiesFiles\\BrowserCommands.properties");
	
	public static Properties getBrowserCommands(String filePath) {
		 Properties pro = new Properties();
		 
		 try {
			FileInputStream stream = new FileInputStream(filePath);
			try {
				pro.load(stream);
			} catch (IOException e) {
				System.out.println("Cannot Read from the properties file");
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		}
		 
		return pro;
	}
	
}
