package data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoadLoginNegativeDataExcel {
	FileInputStream stream = null;
	
	public FileInputStream getExcelFileSheet() throws FileNotFoundException {
		String filePath = System.getProperty("user.dir") +"\\src\\test\\java\\Excel\\LoginData.xlsx";
		
		stream = new FileInputStream(filePath);
		
		return stream;
	}
	
	public Object[][] getExcelFileData() throws IOException{
		stream = getExcelFileSheet();
		
		XSSFWorkbook workBook = new XSSFWorkbook(stream);
		XSSFSheet loginNegativeSheet = workBook.getSheetAt(0);
		
		int nRows = loginNegativeSheet.getLastRowNum() + 1;
		int nCols = 2;
		
		Object[][] loginNegativeData = new Object[nRows][nCols];
		
		for(int i = 0 ; i < nRows ; ++i) {
			XSSFRow row = loginNegativeSheet.getRow(i);
			
			for(int j = 0 ; j < nCols; ++j) {
				loginNegativeData[i][j] = row.getCell(j).toString();	
			}
		}
		
		workBook.close();
		return loginNegativeData;
	}
	
	
}
