package data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LoadLoginNegativeDataProperties {
	public static Properties loginNegativeData = getLoginNegativeData(System.getProperty("user.dir") + "\\src\\test\\java\\PropertiesFiles\\LoginNegativeData.properties");
	
	private static Properties getLoginNegativeData(String filePath) {
		 Properties pro = new Properties();
		 
		 try {
			FileInputStream stream = new FileInputStream(filePath);
			try {
				pro.load(stream);
			} catch (IOException e) {
				System.out.println("Cannot Read from the properties file");
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		}
		 
		return pro;
	}
	
}
